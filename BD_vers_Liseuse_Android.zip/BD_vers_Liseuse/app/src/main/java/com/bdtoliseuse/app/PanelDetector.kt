package com.bdtoliseuse.app

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Portage en Kotlin de l'algorithme de détection des cases utilisé par
 * bd_to_kobo.py (voir detect_panels côté Python) : détection par
 * connexité du fond clair (flood-fill), puis raffinement par analyse
 * de gouttières blanches locales.
 */
object PanelDetector {

    data class Rect(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
        val w get() = x1 - x0
        val h get() = y1 - y0
    }

    class GrayImage(val width: Int, val height: Int) {
        val data = IntArray(width * height)
        inline operator fun get(x: Int, y: Int): Int = data[y * width + x]
        inline operator fun set(x: Int, y: Int, v: Int) { data[y * width + x] = v }
    }

    fun toGray(bmp: Bitmap): GrayImage {
        val w = bmp.width
        val h = bmp.height
        val gray = GrayImage(w, h)
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val lum = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            gray.data[i] = lum.coerceIn(0, 255)
        }
        return gray
    }

    private fun estimateBackgroundLevel(hist: IntArray): Int {
        var peak = 150
        var peakCount = -1
        for (v in 150..255) {
            if (hist[v] > peakCount) { peakCount = hist[v]; peak = v }
        }
        return peak
    }

    private fun globalBackgroundLevel(gray: GrayImage): Int {
        val hist = IntArray(256)
        for (v in gray.data) hist[v]++
        return estimateBackgroundLevel(hist)
    }

    private fun backgroundMask(gray: GrayImage, marginBelowBg: Int = 45): BooleanArray {
        val bg = globalBackgroundLevel(gray)
        val thresh = max(150, bg - marginBelowBg)
        return BooleanArray(gray.data.size) { gray.data[it] >= thresh }
    }

    /** Étiquette les composantes connexes (8-connexité) d'un masque booléen. */
    private fun labelComponents(mask: BooleanArray, w: Int, h: Int): IntArray {
        val labels = IntArray(w * h) { -1 }
        val queue = IntArray(w * h)
        var current = 0
        for (start in 0 until w * h) {
            if (!mask[start] || labels[start] != -1) continue
            var qh = 0
            var qt = 0
            queue[qt++] = start
            labels[start] = current
            while (qh < qt) {
                val idx = queue[qh++]
                val x = idx % w
                val y = idx / w
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue
                    val nIdx = ny * w + nx
                    if (mask[nIdx] && labels[nIdx] == -1) {
                        labels[nIdx] = current
                        queue[qt++] = nIdx
                    }
                }
            }
            current++
        }
        return labels
    }

    private fun mergeOverlapping(boxes: MutableList<Rect>): MutableList<Rect> {
        fun overlaps(a: Rect, b: Rect): Boolean {
            val ix0 = max(a.x0, b.x0); val iy0 = max(a.y0, b.y0)
            val ix1 = min(a.x1, b.x1); val iy1 = min(a.y1, b.y1)
            return ix1 > ix0 && iy1 > iy0
        }
        var changed = true
        while (changed) {
            changed = false
            outer@ for (i in boxes.indices) {
                for (j in i + 1 until boxes.size) {
                    if (overlaps(boxes[i], boxes[j])) {
                        val a = boxes[i]; val b = boxes[j]
                        boxes[i] = Rect(min(a.x0, b.x0), min(a.y0, b.y0), max(a.x1, b.x1), max(a.y1, b.y1))
                        boxes.removeAt(j)
                        changed = true
                        break@outer
                    }
                }
            }
        }
        return boxes
    }

    private fun readingOrder(panels: List<Rect>, yTolFrac: Double = 0.35): List<Rect> {
        if (panels.isEmpty()) return panels
        val avgH = panels.sumOf { it.h }.toDouble() / panels.size
        val tol = avgH * yTolFrac
        val sorted = panels.sortedBy { it.y0 }
        val rows = mutableListOf<MutableList<Rect>>()
        for (p in sorted) {
            val row = rows.firstOrNull { abs(it[0].y0 - p.y0) <= tol }
            if (row != null) row.add(p) else rows.add(mutableListOf(p))
        }
        val result = mutableListOf<Rect>()
        for (row in rows) result.addAll(row.sortedBy { it.x0 })
        return result
    }

    /** Étape 1 : détection par flood-fill du fond clair. */
    fun detectPanels(gray: GrayImage, minPanelFrac: Double = 0.012): List<Rect> {
        val w = gray.width
        val h = gray.height
        val bgMask = backgroundMask(gray)
        val labels = labelComponents(bgMask, w, h)

        val borderLabels = HashSet<Int>()
        for (x in 0 until w) {
            labels[x].let { if (it != -1) borderLabels.add(it) }
            labels[(h - 1) * w + x].let { if (it != -1) borderLabels.add(it) }
        }
        for (y in 0 until h) {
            labels[y * w].let { if (it != -1) borderLabels.add(it) }
            labels[y * w + (w - 1)].let { if (it != -1) borderLabels.add(it) }
        }

        val gutterNetwork = BooleanArray(w * h) { labels[it] != -1 && borderLabels.contains(labels[it]) }
        val panelMask = BooleanArray(w * h) { !gutterNetwork[it] }
        val panelLabels = labelComponents(panelMask, w, h)

        var maxLabel = -1
        for (l in panelLabels) if (l > maxLabel) maxLabel = l
        if (maxLabel < 0) return listOf(Rect(0, 0, w, h))

        val minX = IntArray(maxLabel + 1) { w }
        val minY = IntArray(maxLabel + 1) { h }
        val maxX = IntArray(maxLabel + 1) { 0 }
        val maxY = IntArray(maxLabel + 1) { 0 }
        val area = IntArray(maxLabel + 1)

        for (idx in panelLabels.indices) {
            val lbl = panelLabels[idx]
            if (lbl < 0) continue
            val x = idx % w
            val y = idx / w
            if (x < minX[lbl]) minX[lbl] = x
            if (x > maxX[lbl]) maxX[lbl] = x
            if (y < minY[lbl]) minY[lbl] = y
            if (y > maxY[lbl]) maxY[lbl] = y
            area[lbl]++
        }

        val minArea = minPanelFrac * w * h
        var panels = mutableListOf<Rect>()
        for (lbl in 0..maxLabel) {
            if (area[lbl] < minArea) continue
            val x0 = minX[lbl]; val y0 = minY[lbl]
            val x1 = maxX[lbl] + 1; val y1 = maxY[lbl] + 1
            if ((x1 - x0) < w * 0.04 || (y1 - y0) < h * 0.03) continue
            panels.add(Rect(x0, y0, x1, y1))
        }
        panels = mergeOverlapping(panels)
        if (panels.isEmpty()) panels = mutableListOf(Rect(0, 0, w, h))

        // Étape 2 : raffinement par gouttières blanches locales
        val refined = mutableListOf<Rect>()
        for (p in panels) {
            val pieces = whitespaceRefine(gray, p, w, h, axis = 0, depth = 0)
            if (pieces.size > 6) refined.add(p) else refined.addAll(pieces)
        }
        return readingOrder(refined)
    }

    private fun whitespaceRefine(
        gray: GrayImage, rect: Rect, pageW: Int, pageH: Int,
        axis: Int, depth: Int, maxDepth: Int = 6
    ): List<Rect> {
        val rw = rect.w
        val rh = rect.h
        if (rw < 40 || rh < 40 || depth > maxDepth) return listOf(rect)

        val hist = IntArray(256)
        for (y in rect.y0 until rect.y1) for (x in rect.x0 until rect.x1) hist[gray[x, y]]++
        val peak = estimateBackgroundLevel(hist)
        val bgThresh = max(150, peak - 15)

        val total = if (axis == 0) rh else rw
        val frac = DoubleArray(total)
        if (axis == 0) {
            for (ry in 0 until rh) {
                var cnt = 0
                val y = rect.y0 + ry
                for (x in rect.x0 until rect.x1) if (gray[x, y] >= bgThresh) cnt++
                frac[ry] = cnt.toDouble() / rw
            }
        } else {
            for (rx in 0 until rw) {
                var cnt = 0
                val x = rect.x0 + rx
                for (y in rect.y0 until rect.y1) if (gray[x, y] >= bgThresh) cnt++
                frac[rx] = cnt.toDouble() / rh
            }
        }

        val isGutter = BooleanArray(total) { frac[it] >= 0.80 }
        val bandsRaw = mutableListOf<Pair<Int, Int>>()
        var i = 0
        while (i < total) {
            if (isGutter[i]) {
                var j = i
                while (j < total && isGutter[j]) j++
                bandsRaw.add(i to j)
                i = j
            } else i++
        }

        val pageTotal = if (axis == 0) pageH else pageW
        val maxGutterPx = max(15, (pageTotal * 0.025).toInt())
        val bands = bandsRaw.filter { (it.second - it.first) <= maxGutterPx }

        fun blackFracAt(pos: Int): Double {
            if (pos < 0 || pos >= total) return 0.0
            var cnt = 0
            var tot = 0
            val blackThresh = 90
            if (axis == 0) {
                val y = rect.y0 + pos
                if (y < rect.y0 || y >= rect.y1) return 0.0
                val yStart = max(rect.y0, y - 1); val yEnd = min(rect.y1 - 1, y + 1)
                for (yy in yStart..yEnd) for (x in rect.x0 until rect.x1) { tot++; if (gray[x, yy] < blackThresh) cnt++ }
            } else {
                val x = rect.x0 + pos
                if (x < rect.x0 || x >= rect.x1) return 0.0
                val xStart = max(rect.x0, x - 1); val xEnd = min(rect.x1 - 1, x + 1)
                for (xx in xStart..xEnd) for (y in rect.y0 until rect.y1) { tot++; if (gray[xx, y] < blackThresh) cnt++ }
            }
            return if (tot == 0) 0.0 else cnt.toDouble() / tot
        }

        fun looksLikeRealGutter(b0: Int, b1: Int): Boolean {
            val checkMargin = 20
            val minBlackFrac = 0.22
            var before = 0.0
            for (k in 1 until checkMargin) before = max(before, blackFracAt(b0 - k))
            var after = 0.0
            for (k in 1 until checkMargin) after = max(after, blackFracAt(b1 + k))
            return before >= minBlackFrac || after >= minBlackFrac
        }

        val minSeg = max(30, (pageTotal * 0.045).toInt())
        val segs = mutableListOf<Pair<Int, Int>>()
        var prev = 0
        for ((b0, b1) in bands) {
            val mid = (b0 + b1) / 2
            if (mid - prev >= minSeg && looksLikeRealGutter(b0, b1)) {
                segs.add(prev to mid)
                prev = mid
            }
        }
        if (total - prev >= minSeg) segs.add(prev to total)
        var finalSegs = if (segs.isEmpty()) listOf(0 to total) else segs
        if (finalSegs.size > 6) finalSegs = listOf(0 to total)

        if (finalSegs.size <= 1) {
            val otherAxis = 1 - axis
            return whitespaceRefine(gray, rect, pageW, pageH, otherAxis, depth + 1, maxDepth)
        }

        val out = mutableListOf<Rect>()
        val nextAxis = 1 - axis
        for ((s0, s1) in finalSegs) {
            val sub = if (axis == 0)
                Rect(rect.x0, rect.y0 + s0, rect.x1, rect.y0 + s1)
            else
                Rect(rect.x0 + s0, rect.y0, rect.x0 + s1, rect.y1)
            out.addAll(whitespaceRefine(gray, sub, pageW, pageH, nextAxis, depth + 1, maxDepth))
        }
        return out
    }
}
