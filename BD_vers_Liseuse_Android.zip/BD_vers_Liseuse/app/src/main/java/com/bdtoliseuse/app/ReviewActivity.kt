package com.bdtoliseuse.app

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class ReviewActivity : AppCompatActivity() {

    private lateinit var panelEditView: PanelEditView
    private lateinit var tvPageInfo: TextView
    private lateinit var btnPrev: Button
    private lateinit var btnNext: Button
    private lateinit var btnAddMode: Button
    private lateinit var btnDelete: Button
    private lateinit var btnFinish: Button
    private lateinit var progressBar: ProgressBar

    private var session: ReviewSession? = null
    private var currentIndex = 0
    private var currentBitmap: Bitmap? = null
    private var isBusy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)

        val s = ReviewSessionHolder.session
        if (s == null) {
            Toast.makeText(this, "Session de relecture introuvable.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        session = s

        panelEditView = findViewById(R.id.panelEditView)
        tvPageInfo = findViewById(R.id.tvPageInfo)
        btnPrev = findViewById(R.id.btnPrev)
        btnNext = findViewById(R.id.btnNext)
        btnAddMode = findViewById(R.id.btnAddMode)
        btnDelete = findViewById(R.id.btnDelete)
        btnFinish = findViewById(R.id.btnFinish)
        progressBar = findViewById(R.id.reviewProgressBar)

        btnPrev.setOnClickListener { showPage(currentIndex - 1) }
        btnNext.setOnClickListener { showPage(currentIndex + 1) }

        btnAddMode.setOnClickListener {
            val addingNow = panelEditView.mode == PanelEditView.Mode.ADD
            panelEditView.mode = if (addingNow) PanelEditView.Mode.EDIT else PanelEditView.Mode.ADD
            btnAddMode.text = if (panelEditView.mode == PanelEditView.Mode.ADD) "Dessinez une case…" else "+ Ajouter"
        }

        btnDelete.setOnClickListener { panelEditView.deleteSelected() }

        panelEditView.onBoxesChanged = { updatePageInfo() }
        panelEditView.onSelectionChanged = {
            btnDelete.isEnabled = panelEditView.selectedIndex != -1
        }

        btnFinish.setOnClickListener { finishAndExport() }

        showPage(0)
    }

    private fun showPage(index: Int) {
        val s = session ?: return
        if (index !in s.entryNames.indices) return
        currentIndex = index

        currentBitmap?.recycle()
        val bmp = CbzProcessor.decodePage(s, index)
        if (bmp == null) {
            Toast.makeText(this, "Impossible de lire cette page.", Toast.LENGTH_SHORT).show()
            return
        }
        currentBitmap = bmp
        panelEditView.mode = PanelEditView.Mode.EDIT
        btnAddMode.text = "+ Ajouter"
        panelEditView.setPage(bmp, s.boxesPerPage[index])
        btnDelete.isEnabled = false
        updatePageInfo()

        btnPrev.isEnabled = index > 0
        btnNext.isEnabled = index < s.entryNames.size - 1
    }

    private fun updatePageInfo() {
        val s = session ?: return
        tvPageInfo.text = "Page ${currentIndex + 1} / ${s.entryNames.size} — ${panelEditView.boxCount()} case(s)"
    }

    private fun finishAndExport() {
        if (isBusy) return
        val s = session ?: return
        isBusy = true
        btnFinish.isEnabled = false
        btnPrev.isEnabled = false
        btnNext.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0

        thread(start = true) {
            try {
                val total = CbzProcessor.exportSession(s, contentResolver) { pageIndex, totalPages ->
                    runOnUiThread {
                        progressBar.max = totalPages
                        progressBar.progress = pageIndex
                    }
                }
                runOnUiThread {
                    Toast.makeText(this, "CBZ généré ($total cases)", Toast.LENGTH_LONG).show()
                    ReviewSessionHolder.session = null
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
                    isBusy = false
                    btnFinish.isEnabled = true
                    btnPrev.isEnabled = true
                    btnNext.isEnabled = true
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        currentBitmap?.recycle()
    }
}
