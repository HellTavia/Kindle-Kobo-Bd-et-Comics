package com.bdtoliseuse.app

import android.net.Uri
import java.io.File

/**
 * Représente une BD en cours de relecture : la source déjà copiée en local
 * (CBZ ou PDF), la liste ordonnée des pages, et les cases détectées pour
 * chaque page (modifiables en place par ReviewActivity avant l'export final).
 */
class ReviewSession(
    val sourceType: CbzProcessor.SourceType,
    val sourceFile: File,
    val entryNames: List<String>,
    val boxesPerPage: MutableList<MutableList<PanelDetector.Rect>>,
    val settings: CbzProcessor.Settings,
    val outputUri: Uri
)

/**
 * Contient la session en cours entre MainActivity et ReviewActivity.
 * On évite de la faire transiter par un Intent (les rectangles de toutes
 * les pages peuvent dépasser la limite de taille des transactions Binder) :
 * comme les deux activités tournent dans le même process, un simple
 * singleton suffit.
 */
object ReviewSessionHolder {
    var session: ReviewSession? = null
}
