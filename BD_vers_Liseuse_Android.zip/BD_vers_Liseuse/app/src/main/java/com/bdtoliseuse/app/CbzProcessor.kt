package com.bdtoliseuse.app

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

object CbzProcessor {

    enum class SourceType { ZIP, PDF }

    data class Settings(
        val width: Int,
        val height: Int,
        val quality: Int,
        val grayscale: Boolean,
        val margin: Int = 4,
        val upscaleLimit: Double = 4.0
    )

    private val IMAGE_EXT = listOf(".jpg", ".jpeg", ".png", ".webp", ".bmp")

    /** Points PDF (1/72 pouce) -> pixels, calé sur ~300 dpi comme la version PC. */
    private const val PDF_RENDER_SCALE = 300f / 72f

    /** Tri "naturel" (p2 avant p10) comme le natkey côté Python. */
    private fun naturalKeyTokens(s: String): List<Any> {
        val tokens = mutableListOf<Any>()
        val regex = Regex("(\\d+)")
        var lastIndex = 0
        for (m in regex.findAll(s)) {
            if (m.range.first > lastIndex) tokens.add(s.substring(lastIndex, m.range.first))
            tokens.add(m.value.toLong())
            lastIndex = m.range.last + 1
        }
        if (lastIndex < s.length) tokens.add(s.substring(lastIndex))
        return tokens
    }

    private val naturalComparator = Comparator<String> { a, b ->
        val ta = naturalKeyTokens(a)
        val tb = naturalKeyTokens(b)
        val n = min(ta.size, tb.size)
        for (i in 0 until n) {
            val x = ta[i]; val y = tb[i]
            val cmp = when {
                x is Long && y is Long -> x.compareTo(y)
                x is String && y is String -> x.compareTo(y)
                else -> x.toString().compareTo(y.toString())
            }
            if (cmp != 0) return@Comparator cmp
        }
        ta.size - tb.size
    }

    private fun listSortedImageEntries(zipFile: ZipFile): List<ZipEntry> {
        val all = mutableListOf<ZipEntry>()
        val enumeration = zipFile.entries()
        while (enumeration.hasMoreElements()) all.add(enumeration.nextElement())
        return all
            .filter { entry -> !entry.isDirectory && IMAGE_EXT.any { entry.name.lowercase().endsWith(it) } }
            .sortedWith(compareBy(naturalComparator) { it.name })
    }

    /** Détecte si la source est un PDF (via le type MIME renvoyé par le
     * fournisseur de contenu, puis en repli via le nom de fichier). */
    private fun detectSourceType(resolver: ContentResolver, uri: Uri): SourceType {
        val mime = try { resolver.getType(uri) } catch (e: Exception) { null }
        if (mime == "application/pdf") return SourceType.PDF
        val displayName = try {
            resolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (e: Exception) { null } ?: uri.lastPathSegment
        if (displayName != null && displayName.lowercase().endsWith(".pdf")) return SourceType.PDF
        return SourceType.ZIP
    }

    private fun copyUriToTempFile(resolver: ContentResolver, uri: Uri, prefix: String, sourceType: SourceType): File {
        val suffix = if (sourceType == SourceType.PDF) ".pdf" else ".zip"
        val temp = File.createTempFile(prefix, suffix)
        resolver.openInputStream(uri)?.use { input ->
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        } ?: throw Exception("Impossible de lire le fichier source.")
        return temp
    }

    private fun pageCount(sourceType: SourceType, file: File, entryNames: List<String>): Int {
        return if (sourceType == SourceType.ZIP) {
            entryNames.size
        } else {
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                PdfRenderer(pfd).use { it.pageCount }
            }
        }
    }

    private fun renderPdfPage(file: File, index: Int): Bitmap {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                renderer.openPage(index).use { page ->
                    val w = max(1, (page.width * PDF_RENDER_SCALE).toInt())
                    val h = max(1, (page.height * PDF_RENDER_SCALE).toInt())
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bmp
                }
            }
        }
    }

    private fun decodePageBitmap(sourceType: SourceType, file: File, entryNames: List<String>, index: Int): Bitmap? {
        return if (sourceType == SourceType.ZIP) {
            ZipFile(file).use { zf ->
                val entry = zf.getEntry(entryNames[index]) ?: return null
                val bytes = zf.getInputStream(entry).readBytes()
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
        } else {
            renderPdfPage(file, index)
        }
    }

    private fun toGrayscaleBitmap(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint()
        val cm = ColorMatrix()
        cm.setSaturation(0f)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /** Même logique que fit_no_stretch côté Python : même échelle en X et Y,
     * jamais de déformation, centré sur un fond blanc. */
    private fun fitNoStretch(src: Bitmap, targetW: Int, targetH: Int, upscaleLimit: Double, grayscale: Boolean): Bitmap {
        val working = if (grayscale) toGrayscaleBitmap(src) else src
        val pw = working.width
        val ph = working.height
        val scale = min(min(targetW.toDouble() / pw, targetH.toDouble() / ph), upscaleLimit)
        val newW = max(1, round(pw * scale).toInt())
        val newH = max(1, round(ph * scale).toInt())
        val resized = Bitmap.createScaledBitmap(working, newW, newH, true)

        val canvasBitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(canvasBitmap)
        canvas.drawColor(Color.WHITE)
        val left = (targetW - newW) / 2f
        val top = (targetH - newH) / 2f
        canvas.drawBitmap(resized, left, top, null)

        if (working !== src) working.recycle()
        if (resized !== working) resized.recycle()
        return canvasBitmap
    }

    private fun cropAndFit(bmp: Bitmap, rect: PanelDetector.Rect, settings: Settings): Bitmap {
        val x0 = max(0, rect.x0 - settings.margin)
        val y0 = max(0, rect.y0 - settings.margin)
        val x1 = min(bmp.width, rect.x1 + settings.margin)
        val y1 = min(bmp.height, rect.y1 + settings.margin)
        val cw = max(1, x1 - x0)
        val ch = max(1, y1 - y0)
        val crop = Bitmap.createBitmap(bmp, x0, y0, cw, ch)
        val result = fitNoStretch(crop, settings.width, settings.height, settings.upscaleLimit, settings.grayscale)
        crop.recycle()
        return result
    }

    /**
     * Conversion directe (sans relecture) : détecte et exporte en un seul passage.
     * Accepte un CBZ/ZIP d'images ou un PDF.
     * onProgress(pageIndex, totalPages, panelsOnThisPage) est appelé après chaque page.
     * Retourne le nombre total de cases écrites.
     */
    fun process(
        resolver: ContentResolver,
        inputUri: Uri,
        outputUri: Uri,
        settings: Settings,
        onProgress: (pageIndex: Int, totalPages: Int, panelsOnPage: Int) -> Unit
    ): Int {
        val sourceType = detectSourceType(resolver, inputUri)
        val tempIn = copyUriToTempFile(resolver, inputUri, "bd_in", sourceType)
        try {
            val entryNames = if (sourceType == SourceType.ZIP) {
                ZipFile(tempIn).use { listSortedImageEntries(it).map { e -> e.name } }
            } else emptyList()
            val total = pageCount(sourceType, tempIn, entryNames)
            if (total == 0) throw Exception("Aucune page trouvée dans ce fichier.")

            val outStream = resolver.openOutputStream(outputUri)
                ?: throw Exception("Impossible d'écrire le fichier de sortie.")

            var totalPanels = 0
            ZipOutputStream(BufferedOutputStream(outStream)).use { zos ->
                for (pageIndex in 0 until total) {
                    val bmp = decodePageBitmap(sourceType, tempIn, entryNames, pageIndex)
                    if (bmp == null) {
                        onProgress(pageIndex + 1, total, 0)
                        continue
                    }
                    val gray = PanelDetector.toGray(bmp)
                    val panels = PanelDetector.detectPanels(gray)
                    for (rect in panels) {
                        val canvasBitmap = cropAndFit(bmp, rect, settings)
                        totalPanels++
                        zos.putNextEntry(ZipEntry(String.format("%04d.jpg", totalPanels)))
                        canvasBitmap.compress(Bitmap.CompressFormat.JPEG, settings.quality, zos)
                        zos.closeEntry()
                        canvasBitmap.recycle()
                    }
                    bmp.recycle()
                    onProgress(pageIndex + 1, total, panels.size)
                }
            }
            return totalPanels
        } finally {
            tempIn.delete()
        }
    }

    /**
     * Prépare une session de relecture : copie la source (CBZ ou PDF), détecte
     * les cases de chaque page, et retourne une ReviewSession éditable.
     */
    fun prepareReviewSession(
        resolver: ContentResolver,
        inputUri: Uri,
        outputUri: Uri,
        settings: Settings,
        onProgress: (pageIndex: Int, totalPages: Int) -> Unit
    ): ReviewSession {
        val sourceType = detectSourceType(resolver, inputUri)
        val tempIn = copyUriToTempFile(resolver, inputUri, "bd_review", sourceType)

        val entryNames = if (sourceType == SourceType.ZIP) {
            ZipFile(tempIn).use { listSortedImageEntries(it).map { e -> e.name } }
        } else emptyList()
        val total = pageCount(sourceType, tempIn, entryNames)
        if (total == 0) {
            tempIn.delete()
            throw Exception("Aucune page trouvée dans ce fichier.")
        }

        val boxesPerPage = mutableListOf<MutableList<PanelDetector.Rect>>()
        for (i in 0 until total) {
            val bmp = decodePageBitmap(sourceType, tempIn, entryNames, i)
            if (bmp == null) {
                boxesPerPage.add(mutableListOf())
            } else {
                val gray = PanelDetector.toGray(bmp)
                boxesPerPage.add(PanelDetector.detectPanels(gray).toMutableList())
                bmp.recycle()
            }
            onProgress(i + 1, total)
        }
        return ReviewSession(sourceType, tempIn, entryNames, boxesPerPage, settings, outputUri)
    }

    /**
     * Exporte le CBZ final à partir d'une ReviewSession dont les rectangles
     * ont potentiellement été corrigés manuellement.
     */
    fun exportSession(
        session: ReviewSession,
        resolver: ContentResolver,
        onProgress: (pageIndex: Int, totalPages: Int) -> Unit
    ): Int {
        try {
            val outStream = resolver.openOutputStream(session.outputUri)
                ?: throw Exception("Impossible d'écrire le fichier de sortie.")

            var totalPanels = 0
            ZipOutputStream(BufferedOutputStream(outStream)).use { zos ->
                for (i in session.boxesPerPage.indices) {
                    val bmp = decodePageBitmap(session.sourceType, session.sourceFile, session.entryNames, i)
                    if (bmp != null) {
                        for (rect in session.boxesPerPage[i]) {
                            val canvasBitmap = cropAndFit(bmp, rect, session.settings)
                            totalPanels++
                            zos.putNextEntry(ZipEntry(String.format("%04d.jpg", totalPanels)))
                            canvasBitmap.compress(Bitmap.CompressFormat.JPEG, session.settings.quality, zos)
                            zos.closeEntry()
                            canvasBitmap.recycle()
                        }
                        bmp.recycle()
                    }
                    onProgress(i + 1, session.boxesPerPage.size)
                }
            }
            return totalPanels
        } finally {
            session.sourceFile.delete()
        }
    }

    /** Décode la page à l'index donné (pour l'affichage dans ReviewActivity). */
    fun decodePage(session: ReviewSession, index: Int): Bitmap? {
        return decodePageBitmap(session.sourceType, session.sourceFile, session.entryNames, index)
    }
}
