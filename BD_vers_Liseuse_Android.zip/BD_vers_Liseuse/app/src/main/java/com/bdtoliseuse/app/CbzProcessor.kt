package com.bdtoliseuse.app

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

object CbzProcessor {

    data class Settings(
        val width: Int,
        val height: Int,
        val quality: Int,
        val grayscale: Boolean,
        val margin: Int = 4,
        val upscaleLimit: Double = 4.0
    )

    private val IMAGE_EXT = listOf(".jpg", ".jpeg", ".png", ".webp", ".bmp")

    /** Tri "naturel" (p2 avant p10) comme le natkey côté Python. */
    private fun naturalKeyTokens(s: String): List<Any> {
        val tokens = mutableListOf<Any>()
        val regex = Regex("(\\d+)")
        var lastIndex = 0
        for (m in regex.findAll(s)) {
            if (m.range.first > lastIndex) tokens.add(s.substring(lastIndex, m.range.first))
            tokens.add(m.value.toLong())
            lastIndex = m.range.last + 1
        }
        if (lastIndex < s.length) tokens.add(s.substring(lastIndex))
        return tokens
    }

    private val naturalComparator = Comparator<String> { a, b ->
        val ta = naturalKeyTokens(a)
        val tb = naturalKeyTokens(b)
        val n = min(ta.size, tb.size)
        for (i in 0 until n) {
            val x = ta[i]; val y = tb[i]
            val cmp = when {
                x is Long && y is Long -> x.compareTo(y)
                x is String && y is String -> x.compareTo(y)
                else -> x.toString().compareTo(y.toString())
            }
            if (cmp != 0) return@Comparator cmp
        }
        ta.size - tb.size
    }

    private fun toGrayscaleBitmap(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint()
        val cm = ColorMatrix()
        cm.setSaturation(0f)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /** Même logique que fit_no_stretch côté Python : même échelle en X et Y,
     * jamais de déformation, centré sur un fond blanc. */
    private fun fitNoStretch(src: Bitmap, targetW: Int, targetH: Int, upscaleLimit: Double, grayscale: Boolean): Bitmap {
        val working = if (grayscale) toGrayscaleBitmap(src) else src
        val pw = working.width
        val ph = working.height
        val scale = min(min(targetW.toDouble() / pw, targetH.toDouble() / ph), upscaleLimit)
        val newW = max(1, round(pw * scale).toInt())
        val newH = max(1, round(ph * scale).toInt())
        val resized = Bitmap.createScaledBitmap(working, newW, newH, true)

        val canvasBitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(canvasBitmap)
        canvas.drawColor(Color.WHITE)
        val left = (targetW - newW) / 2f
        val top = (targetH - newH) / 2f
        canvas.drawBitmap(resized, left, top, null)

        if (working !== src) working.recycle()
        if (resized !== working) resized.recycle()
        return canvasBitmap
    }

    /**
     * Traite le CBZ d'entrée et écrit le CBZ de sortie.
     * onProgress(pageIndex, totalPages, panelsOnThisPage) est appelé après
     * chaque page traitée (depuis le thread appelant, pas forcément le thread UI).
     * Retourne le nombre total de cases écrites.
     */
    fun process(
        resolver: ContentResolver,
        inputUri: Uri,
        outputUri: Uri,
        settings: Settings,
        onProgress: (pageIndex: Int, totalPages: Int, panelsOnPage: Int) -> Unit
    ): Int {
        val tempIn = File.createTempFile("bd_in", ".zip")
        try {
            resolver.openInputStream(inputUri)?.use { input ->
                FileOutputStream(tempIn).use { output -> input.copyTo(output) }
            } ?: throw Exception("Impossible de lire le fichier source.")

            val zipFile = ZipFile(tempIn)
            val allEntries = mutableListOf<ZipEntry>()
            val enumeration = zipFile.entries()
            while (enumeration.hasMoreElements()) {
                allEntries.add(enumeration.nextElement())
            }
            val entries = allEntries
                .filter { entry ->
                    !entry.isDirectory && IMAGE_EXT.any { entry.name.lowercase().endsWith(it) }
                }
                .sortedWith(compareBy(naturalComparator) { it.name })

            if (entries.isEmpty()) {
                zipFile.close()
                throw Exception("Aucune image trouvée dans ce fichier.")
            }

            val outStream = resolver.openOutputStream(outputUri)
                ?: throw Exception("Impossible d'écrire le fichier de sortie.")

            var totalPanels = 0
            ZipOutputStream(BufferedOutputStream(outStream)).use { zos ->
                for ((pageIndex, entry) in entries.withIndex()) {
                    val bytes = zipFile.getInputStream(entry).readBytes()
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp == null) {
                        onProgress(pageIndex + 1, entries.size, 0)
                        continue
                    }

                    val gray = PanelDetector.toGray(bmp)
                    val panels = PanelDetector.detectPanels(gray)

                    for (rect in panels) {
                        val x0 = max(0, rect.x0 - settings.margin)
                        val y0 = max(0, rect.y0 - settings.margin)
                        val x1 = min(bmp.width, rect.x1 + settings.margin)
                        val y1 = min(bmp.height, rect.y1 + settings.margin)
                        val cw = max(1, x1 - x0)
                        val ch = max(1, y1 - y0)
                        val crop = Bitmap.createBitmap(bmp, x0, y0, cw, ch)
                        val canvasBitmap = fitNoStretch(crop, settings.width, settings.height, settings.upscaleLimit, settings.grayscale)

                        totalPanels++
                        val entryName = String.format("%04d.jpg", totalPanels)
                        zos.putNextEntry(ZipEntry(entryName))
                        canvasBitmap.compress(Bitmap.CompressFormat.JPEG, settings.quality, zos)
                        zos.closeEntry()

                        crop.recycle()
                        canvasBitmap.recycle()
                    }
                    bmp.recycle()
                    onProgress(pageIndex + 1, entries.size, panels.size)
                }
            }
            zipFile.close()
            return totalPanels
        } finally {
            tempIn.delete()
        }
    }
}
