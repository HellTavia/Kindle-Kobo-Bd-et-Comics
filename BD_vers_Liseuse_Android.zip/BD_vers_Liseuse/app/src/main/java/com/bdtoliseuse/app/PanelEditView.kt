package com.bdtoliseuse.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Équivalent tactile de l'outil revue.html : affiche la page en l'ajustant
 * à la vue (sans déformation), dessine les cases détectées par-dessus, et
 * permet de les déplacer / redimensionner / ajouter / sélectionner au doigt.
 * La suppression se fait via un bouton externe (deleteSelected()).
 */
class PanelEditView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { EDIT, ADD }

    var mode: Mode = Mode.EDIT
    var onBoxesChanged: (() -> Unit)? = null
    var onSelectionChanged: (() -> Unit)? = null

    private var bitmap: Bitmap? = null
    private var boxes: MutableList<PanelDetector.Rect> = mutableListOf()
    var selectedIndex: Int = -1
        private set

    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.RED
        strokeWidth = 4f
    }
    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.GREEN
        strokeWidth = 5f
    }
    private val newBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.BLUE
        strokeWidth = 4f
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.GREEN
    }
    private val handleRadiusPx = 18f
    private val handleHitRadiusPx = 50f
    private val minBoxPx = 20

    // état d'interaction en cours
    private var draggingBox = false
    private var activeCorner = -1 // 0=NW 1=NE 2=SW 3=SE
    private var dragStartImgX = 0f
    private var dragStartImgY = 0f
    private var dragOrigBox: PanelDetector.Rect? = null
    private var drawStartView: Pair<Float, Float>? = null
    private var drawCurrentView: Pair<Float, Float>? = null

    fun setPage(bmp: Bitmap, boxList: MutableList<PanelDetector.Rect>) {
        bitmap = bmp
        boxes = boxList
        selectedIndex = -1
        draggingBox = false
        activeCorner = -1
        drawStartView = null
        drawCurrentView = null
        requestLayout()
        invalidate()
    }

    fun deleteSelected() {
        if (selectedIndex in boxes.indices) {
            boxes.removeAt(selectedIndex)
            selectedIndex = -1
            invalidate()
            onBoxesChanged?.invoke()
            onSelectionChanged?.invoke()
        }
    }

    fun boxCount(): Int = boxes.size

    private fun recomputeTransform() {
        val bmp = bitmap ?: return
        if (width <= 0 || height <= 0) return
        val sx = width.toFloat() / bmp.width
        val sy = height.toFloat() / bmp.height
        scale = min(sx, sy)
        offsetX = (width - bmp.width * scale) / 2f
        offsetY = (height - bmp.height * scale) / 2f
    }

    private fun viewToImage(vx: Float, vy: Float): Pair<Float, Float> {
        if (scale <= 0f) return 0f to 0f
        return (vx - offsetX) / scale to (vy - offsetY) / scale
    }

    private fun imageToView(ix: Float, iy: Float): Pair<Float, Float> {
        return ix * scale + offsetX to iy * scale + offsetY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = bitmap ?: return
        recomputeTransform()

        canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)
        canvas.drawBitmap(bmp, 0f, 0f, null)
        for ((i, r) in boxes.withIndex()) {
            val paint = if (i == selectedIndex) selectedPaint else boxPaint
            canvas.drawRect(r.x0.toFloat(), r.y0.toFloat(), r.x1.toFloat(), r.y1.toFloat(), paint)
        }
        canvas.restore()

        val ds = drawStartView
        val dc = drawCurrentView
        if (mode == Mode.ADD && ds != null && dc != null) {
            canvas.drawRect(
                min(ds.first, dc.first), min(ds.second, dc.second),
                max(ds.first, dc.first), max(ds.second, dc.second),
                newBoxPaint
            )
        }

        if (selectedIndex in boxes.indices) {
            val r = boxes[selectedIndex]
            val corners = listOf(r.x0 to r.y0, r.x1 to r.y0, r.x0 to r.y1, r.x1 to r.y1)
            for ((ix, iy) in corners) {
                val (vx, vy) = imageToView(ix.toFloat(), iy.toFloat())
                canvas.drawCircle(vx, vy, handleRadiusPx, handlePaint)
            }
        }
    }

    private fun hitTestCorner(r: PanelDetector.Rect, vx: Float, vy: Float): Int {
        val corners = listOf(r.x0 to r.y0, r.x1 to r.y0, r.x0 to r.y1, r.x1 to r.y1)
        for ((idx, c) in corners.withIndex()) {
            val (cvx, cvy) = imageToView(c.first.toFloat(), c.second.toFloat())
            if (abs(vx - cvx) <= handleHitRadiusPx && abs(vy - cvy) <= handleHitRadiusPx) return idx
        }
        return -1
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bmp = bitmap ?: return false
        if (scale <= 0f) recomputeTransform()

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (mode == Mode.ADD) {
                    drawStartView = event.x to event.y
                    drawCurrentView = event.x to event.y
                    invalidate()
                    return true
                }

                if (selectedIndex in boxes.indices) {
                    val corner = hitTestCorner(boxes[selectedIndex], event.x, event.y)
                    if (corner != -1) {
                        activeCorner = corner
                        dragOrigBox = boxes[selectedIndex]
                        return true
                    }
                }

                val (imgX, imgY) = viewToImage(event.x, event.y)
                val hitIdx = boxes.indices.reversed().firstOrNull { idx ->
                    val r = boxes[idx]
                    imgX >= r.x0 && imgX <= r.x1 && imgY >= r.y0 && imgY <= r.y1
                }
                selectedIndex = hitIdx ?: -1
                if (hitIdx != null) {
                    draggingBox = true
                    dragStartImgX = imgX
                    dragStartImgY = imgY
                    dragOrigBox = boxes[hitIdx]
                }
                onSelectionChanged?.invoke()
                invalidate()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (mode == Mode.ADD && drawStartView != null) {
                    drawCurrentView = event.x to event.y
                    invalidate()
                    return true
                }

                if (activeCorner != -1 && selectedIndex in boxes.indices) {
                    val orig = dragOrigBox ?: return true
                    val (imgX, imgY) = viewToImage(event.x, event.y)
                    var x0 = orig.x0; var y0 = orig.y0; var x1 = orig.x1; var y1 = orig.y1
                    when (activeCorner) {
                        0 -> { x0 = imgX.toInt().coerceIn(0, x1 - minBoxPx); y0 = imgY.toInt().coerceIn(0, y1 - minBoxPx) }
                        1 -> { x1 = imgX.toInt().coerceIn(x0 + minBoxPx, bmp.width); y0 = imgY.toInt().coerceIn(0, y1 - minBoxPx) }
                        2 -> { x0 = imgX.toInt().coerceIn(0, x1 - minBoxPx); y1 = imgY.toInt().coerceIn(y0 + minBoxPx, bmp.height) }
                        3 -> { x1 = imgX.toInt().coerceIn(x0 + minBoxPx, bmp.width); y1 = imgY.toInt().coerceIn(y0 + minBoxPx, bmp.height) }
                    }
                    boxes[selectedIndex] = PanelDetector.Rect(x0, y0, x1, y1)
                    invalidate()
                    return true
                }

                if (draggingBox && selectedIndex in boxes.indices) {
                    val orig = dragOrigBox ?: return true
                    val (imgX, imgY) = viewToImage(event.x, event.y)
                    val dx = (imgX - dragStartImgX).toInt()
                    val dy = (imgY - dragStartImgY).toInt()
                    val w = orig.x1 - orig.x0
                    val h = orig.y1 - orig.y0
                    val nx0 = (orig.x0 + dx).coerceIn(0, bmp.width - w)
                    val ny0 = (orig.y0 + dy).coerceIn(0, bmp.height - h)
                    boxes[selectedIndex] = PanelDetector.Rect(nx0, ny0, nx0 + w, ny0 + h)
                    invalidate()
                    return true
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.ADD) {
                    val ds = drawStartView
                    val dc = drawCurrentView
                    if (ds != null && dc != null) {
                        val (ix0, iy0) = viewToImage(min(ds.first, dc.first), min(ds.second, dc.second))
                        val (ix1, iy1) = viewToImage(max(ds.first, dc.first), max(ds.second, dc.second))
                        val rx0 = ix0.toInt().coerceIn(0, bmp.width)
                        val ry0 = iy0.toInt().coerceIn(0, bmp.height)
                        val rx1 = ix1.toInt().coerceIn(0, bmp.width)
                        val ry1 = iy1.toInt().coerceIn(0, bmp.height)
                        if (rx1 - rx0 > 15 && ry1 - ry0 > 15) {
                            boxes.add(PanelDetector.Rect(rx0, ry0, rx1, ry1))
                            selectedIndex = boxes.size - 1
                            onBoxesChanged?.invoke()
                            onSelectionChanged?.invoke()
                        }
                    }
                    drawStartView = null
                    drawCurrentView = null
                    invalidate()
                    return true
                }

                if (draggingBox || activeCorner != -1) {
                    onBoxesChanged?.invoke()
                }
                draggingBox = false
                activeCorner = -1
                dragOrigBox = null
            }
        }
        return true
    }
}
