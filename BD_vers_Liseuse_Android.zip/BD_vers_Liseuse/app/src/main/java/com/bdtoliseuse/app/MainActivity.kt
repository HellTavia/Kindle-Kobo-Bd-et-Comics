package com.bdtoliseuse.app

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var tvSelectedFile: TextView
    private lateinit var tvLog: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var radioPreset: RadioGroup
    private lateinit var etWidth: EditText
    private lateinit var etHeight: EditText
    private lateinit var etQuality: EditText
    private lateinit var cbGrayscale: CheckBox
    private lateinit var btnGenerate: Button
    private lateinit var btnPickFile: Button

    private var inputUri: Uri? = null
    private var inputDisplayName: String = ""
    private var isBusy = false

    private val pickFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            inputUri = uri
            inputDisplayName = queryDisplayName(uri) ?: uri.lastPathSegment ?: "fichier choisi"
            tvSelectedFile.text = inputDisplayName
        }
    }

    private val createFileLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) startConversion(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSelectedFile = findViewById(R.id.tvSelectedFile)
        tvLog = findViewById(R.id.tvLog)
        progressBar = findViewById(R.id.progressBar)
        radioPreset = findViewById(R.id.radioPreset)
        etWidth = findViewById(R.id.etWidth)
        etHeight = findViewById(R.id.etHeight)
        etQuality = findViewById(R.id.etQuality)
        cbGrayscale = findViewById(R.id.cbGrayscale)
        btnGenerate = findViewById(R.id.btnGenerate)
        btnPickFile = findViewById(R.id.btnPickFile)

        btnPickFile.setOnClickListener {
            pickFileLauncher.launch(arrayOf("*/*"))
        }

        radioPreset.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.radioLibra -> applyPreset(1264, 1680, 90, false)
                R.id.radioPaperwhite -> applyPreset(758, 1024, 80, true)
                // "Personnalisé" : on laisse les valeurs actuelles telles quelles
            }
        }

        btnGenerate.setOnClickListener { onGenerateClicked() }
    }

    private fun applyPreset(w: Int, h: Int, q: Int, gray: Boolean) {
        etWidth.setText(w.toString())
        etHeight.setText(h.toString())
        etQuality.setText(q.toString())
        cbGrayscale.isChecked = gray
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun onGenerateClicked() {
        if (isBusy) {
            Toast.makeText(this, "Une conversion est déjà en cours.", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = inputUri
        if (uri == null) {
            Toast.makeText(this, "Choisissez d'abord un fichier .cbz.", Toast.LENGTH_SHORT).show()
            return
        }
        val suggestedName = inputDisplayName.substringBeforeLast(".", inputDisplayName) + "_liseuse.cbz"
        createFileLauncher.launch(suggestedName)
    }

    private fun readSettings(): CbzProcessor.Settings? {
        val width = etWidth.text.toString().toIntOrNull()
        val height = etHeight.text.toString().toIntOrNull()
        val quality = etQuality.text.toString().toIntOrNull()
        if (width == null || height == null || quality == null || width <= 0 || height <= 0 || quality !in 1..100) {
            Toast.makeText(this, "Vérifiez largeur / hauteur / qualité (nombres attendus).", Toast.LENGTH_LONG).show()
            return null
        }
        return CbzProcessor.Settings(
            width = width,
            height = height,
            quality = quality,
            grayscale = cbGrayscale.isChecked
        )
    }

    private fun startConversion(outputUri: Uri) {
        val settings = readSettings() ?: return
        val uri = inputUri ?: return

        isBusy = true
        btnGenerate.isEnabled = false
        btnPickFile.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        tvLog.text = "Démarrage…\n"

        thread(start = true) {
            try {
                val total = CbzProcessor.process(contentResolver, uri, outputUri, settings) { pageIndex, totalPages, panelsOnPage ->
                    runOnUiThread {
                        progressBar.max = totalPages
                        progressBar.progress = pageIndex
                        appendLog("Page $pageIndex/$totalPages : $panelsOnPage case(s)")
                    }
                }
                runOnUiThread {
                    appendLog("\nTerminé : $total case(s) au total.")
                    Toast.makeText(this, "CBZ généré ($total cases)", Toast.LENGTH_LONG).show()
                    finishBusy()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    appendLog("\nERREUR : ${e.message}")
                    Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
                    finishBusy()
                }
            }
        }
    }

    private fun finishBusy() {
        isBusy = false
        btnGenerate.isEnabled = true
        btnPickFile.isEnabled = true
        progressBar.visibility = View.GONE
    }

    private fun appendLog(line: String) {
        tvLog.append(line + "\n")
    }
}
